========================
Odoo Mondial Relay Shipping Integration
========================

Features
========================================
-shipment will send in mondial relay
-When Validate Delivery Order in Odoo Label is Generated and Attached in Delivery Order.
-Generate Live Shipment Tracking Number
-Multipackages is not Supported
-Rate Not Given
-Location Is Given If Parcel in Domestic

