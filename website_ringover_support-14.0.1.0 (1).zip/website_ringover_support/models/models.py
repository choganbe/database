# -*- coding: utf-8 -*-
from odoo import models, fields, api


class ResCompany(models.Model):
    _inherit = "res.company"

    ringover_number_id = fields.Char("Ringover Number/ ID", help="Provide your ringover id")
