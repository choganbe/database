# -*- coding: utf-8 -*-
{
    'name': "Website Ringover Support",

    'summary': """Integrate your Ringover Support in Odoo""",

    'description': """Support your customers using 'Website Ringover Support' in Odoo""",

    'author': 'ErpMstar Solutions',
    'category': 'Website',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['website'],

    # always loaded
    'data': [
        'views/views.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
    'images': ['static/description/call.jpg'],
    'price': 15,
    'currency': 'EUR',
    'installable': True,
}
